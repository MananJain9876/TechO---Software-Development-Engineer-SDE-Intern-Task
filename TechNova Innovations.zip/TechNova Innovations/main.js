document.querySelectorAll('.nav-links a').forEach(link => {
    link.addEventListener('click', e => {
        e.preventDefault();
        const targetId = link.getAttribute('href').slice(1);
        const targetElement = document.getElementById(targetId);
        if (targetElement) {
            targetElement.scrollIntoView({ behavior: 'smooth' });
        }
    });
});
const darkModeToggle = document.createElement('button');
darkModeToggle.textContent = 'Toggle Dark Mode';
darkModeToggle.style.position = 'fixed';
darkModeToggle.style.bottom = '20px';
darkModeToggle.style.right = '20px';
darkModeToggle.style.padding = '10px';
darkModeToggle.style.backgroundColor = '#007BFF';
darkModeToggle.style.color = '#FFF';
darkModeToggle.style.border = 'none';
darkModeToggle.style.borderRadius = '5px';
darkModeToggle.style.cursor = 'pointer';

document.body.appendChild(darkModeToggle);

darkModeToggle.addEventListener('click', () => {
    document.body.classList.toggle('dark-mode');
});

document.head.insertAdjacentHTML('beforeend', `
<style>
    body.dark-mode {
        background-color: #121212;
        color: #FFF;
    }

    body.dark-mode header {
        background-color: #1E1E1E;
    }

    body.dark-mode .card {
        background-color: #1E1E1E;
        color: #FFF;
    }

    body.dark-mode footer {
        background-color: #1E1E1E;
    }
</style>
`);
const scrollToTopBtn = document.createElement('button');
scrollToTopBtn.innerText = "↑";
scrollToTopBtn.style.position = "fixed";
scrollToTopBtn.style.bottom = "20px";
scrollToTopBtn.style.right = "20px";
scrollToTopBtn.style.background = "linear-gradient(90deg, #4e54c8, #8f94fb)";
scrollToTopBtn.style.color = "#fff";
scrollToTopBtn.style.padding = "10px 15px";
scrollToTopBtn.style.border = "none";
scrollToTopBtn.style.borderRadius = "50%";
scrollToTopBtn.style.cursor = "pointer";
scrollToTopBtn.style.display = "none"; 
scrollToTopBtn.style.zIndex = "1000";

document.body.appendChild(scrollToTopBtn);

window.addEventListener('scroll', () => {
  if (window.scrollY > 300) {
    scrollToTopBtn.style.display = "block";
  } else {
    scrollToTopBtn.style.display = "none";
  }
});
scrollToTopBtn.addEventListener('click', () => {
  window.scrollTo({ top: 0, behavior: 'smooth' });
});
