document.querySelectorAll('.nav-links a').forEach(link => {
    link.addEventListener('click', e => {
        e.preventDefault();
        const targetId = link.getAttribute('href').slice(1);
        const targetElement = document.getElementById(targetId);
        if (targetElement) {
            targetElement.scrollIntoView({ behavior: 'smooth' });
        }
    });
});

// Dark mode toggle
const darkModeToggle = document.createElement('button');
darkModeToggle.textContent = 'Toggle Dark Mode';
darkModeToggle.style.position = 'fixed';
darkModeToggle.style.bottom = '20px';
darkModeToggle.style.right = '20px';
darkModeToggle.style.padding = '10px';
darkModeToggle.style.backgroundColor = '#007BFF';
darkModeToggle.style.color = '#FFF';
darkModeToggle.style.border = 'none';
darkModeToggle.style.borderRadius = '5px';
darkModeToggle.style.cursor = 'pointer';

document.body.appendChild(darkModeToggle);

darkModeToggle.addEventListener('click', () => {
    document.body.classList.toggle('dark-mode');
});

// Add dark mode styles dynamically
document.head.insertAdjacentHTML('beforeend', `
<style>
    body.dark-mode {
        background-color: #121212;
        color: #FFF;
    }

    body.dark-mode header {
        background-color: #1E1E1E;
    }

    body.dark-mode .card {
        background-color: #1E1E1E;
        color: #FFF;
    }

    body.dark-mode footer {
        background-color: #1E1E1E;
    }
</style>
`);